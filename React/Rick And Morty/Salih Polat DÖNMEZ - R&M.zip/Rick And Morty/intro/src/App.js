import Character from "./pages/character";

function App() {

  return (
    <div className="App">
      <div className="characterApp">
        <Character />
      </div>
    </div>
  );
}

export default App;